﻿using UnityEngine;
using System.Collections;

public class PartsHolder : MonoBehaviour
{
	public GameObject[] explosion_parts = {};
}
