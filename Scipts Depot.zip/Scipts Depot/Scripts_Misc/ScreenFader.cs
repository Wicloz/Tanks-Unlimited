﻿using UnityEngine;
using System.Collections;

public class ScreenFader : MonoBehaviour
{
	public float fadeSpeed;
	public bool sceneStarting = true;
	private bool sceneEnding = false;
	private string nextLevel;

	public void ChangeScene (string level)
	{
		Time.timeScale = 1f;
		Time.fixedDeltaTime = 0.02f;
		nextLevel = level;
		sceneStarting = false;
		sceneEnding = true;
		GetComponent<GUITexture>().color = Color.clear;
		gameObject.SetActive (true);
	}
	
	public void SetClear ()
	{
		sceneStarting = false;
		GetComponent<GUITexture>().color = Color.clear;
		gameObject.SetActive (false);
	}

	void Update ()
	{
		if (sceneStarting)
		{
			GetComponent<GUITexture>().pixelInset = new Rect (0, 0, Screen.width, Screen.height);
			StartingScene ();
		}

		if (sceneEnding)
		{
			GetComponent<GUITexture>().pixelInset = new Rect (0, 0, Screen.width, Screen.height);
			EndingScene ();
		}
	}

	void StartingScene ()
	{
		FadeToClear ();
		if (GetComponent<GUITexture>().color.a <= 0.05f)
		{
			SetClear ();
		}
	}

	void EndingScene ()
	{
		FadeToBlack ();
		if (GetComponent<GUITexture>().color.a >= 0.95f)
		{
			sceneEnding = false;
			GetComponent<GUITexture>().color = Color.black;
			if (nextLevel != "none")
			{
				Application.LoadLevel (nextLevel);
			}
		}
	}

	void FadeToClear ()
	{
		GetComponent<GUITexture>().color = Color.Lerp (GetComponent<GUITexture>().color, Color.clear, fadeSpeed * Time.deltaTime);
	}

	void FadeToBlack ()
	{
		GetComponent<GUITexture>().color = Color.Lerp (GetComponent<GUITexture>().color, Color.black, fadeSpeed * Time.deltaTime);
	}
}
