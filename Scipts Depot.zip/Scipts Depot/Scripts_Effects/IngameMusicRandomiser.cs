﻿using UnityEngine;
using System.Collections;

public class IngameMusicRandomiser : MonoBehaviour
{
	public static IngameMusicRandomiser acces;

	public AudioClip gameOverClip;
	public AudioClip[] musicTracks;
	private AudioSource musicPlayer;
	private bool gameOverRunning = false;

	void Awake ()
	{
		if (acces == null)
		{
			DontDestroyOnLoad(gameObject);
			acces = this;
		}
		else if (acces != this)
		{
			Destroy (gameObject);
		}
	}

	void Start ()
	{
		musicPlayer = gameObject.AddComponent<AudioSource>();
		PickRandomMusic ();
	}

	void Update ()
	{
		musicPlayer.volume = GlobalValues.acces.musicVolume;

		if (GameStates.acces.GameOver && !gameOverRunning)
		{
			gameOverRunning = true;
			GetComponent<AudioSource>().Stop ();
			musicPlayer.clip = gameOverClip;
			musicPlayer.GetComponent<AudioSource>().loop = true;
			GetComponent<AudioSource>().Play ();
		}

		if (!GetComponent<AudioSource>().isPlaying)
		{
			PickRandomMusic ();
		}
	}

	void PickRandomMusic ()
	{
		int random = (int)Random.Range (-0.5f, musicTracks.Length - 0.5f);
		for (int i = 0; i < musicTracks.Length; i ++)
		{
			if (i == random)
			{
				musicPlayer.clip = musicTracks[i];
				GetComponent<AudioSource>().Play ();
			}
		}
	}
}
