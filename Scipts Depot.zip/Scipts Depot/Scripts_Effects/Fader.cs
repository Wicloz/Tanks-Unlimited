﻿using UnityEngine;
using System.Collections;

public class Fader : MonoBehaviour
{
	void Start ()
	{
		if (GetComponent<GUIText>() != null)
		{
			GetComponent<GUIText>().color = new Vector4 (GetComponent<GUIText>().color.r, GetComponent<GUIText>().color.g, GetComponent<GUIText>().color.b, 0);
		}
		
		if (GetComponent<GUITexture>() != null)
		{
			GetComponent<GUITexture>().color = new Vector4 (GetComponent<GUITexture>().color.r, GetComponent<GUITexture>().color.g, GetComponent<GUITexture>().color.b, 0);
		}
	}

	void Update ()
	{
		if (GetComponent<GUIText>() != null)
		{
			GetComponent<GUIText>().color = Vector4.Lerp (GetComponent<GUIText>().color, new Vector4 (GetComponent<GUIText>().color.r, GetComponent<GUIText>().color.g, GetComponent<GUIText>().color.b, 255), Time.deltaTime / 100);
		}

		if (GetComponent<GUITexture>() != null)
		{
			GetComponent<GUITexture>().color = Vector4.Lerp (GetComponent<GUITexture>().color, new Vector4 (GetComponent<GUITexture>().color.r, GetComponent<GUITexture>().color.g, GetComponent<GUITexture>().color.b, 255), Time.deltaTime / 100);
		}
	}
}
